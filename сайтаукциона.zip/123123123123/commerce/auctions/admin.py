from .models import User, Bid, Item, ItemComment, ItemCategory, Category
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin


class ItemAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'title', 'starting_bid', 'category', 'status')
    list_display_links = ('title',)
    search_fields = ('title', 'description', 'user')
    list_editable = ('category', 'status')
    list_filter = ('status', 'category')


class ItemCommentAdmin(admin.ModelAdmin):
    list_display = ('item', 'author', 'crated_at')
    list_display_links = ('item',)


class ItemCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'item')
    list_display_links = ('name',)


class BidAdmin(admin.ModelAdmin):
    list_display = ('id', 'items', 'user', 'amount')
    list_display_links = ('items',)


# Register your models here.
admin.site.register(User, UserAdmin)
admin.site.register(Item, ItemAdmin)
admin.site.register(Bid, BidAdmin)
admin.site.register(ItemComment, ItemCommentAdmin)
admin.site.register(ItemCategory, ItemCategoryAdmin)
admin.site.register(Category)
