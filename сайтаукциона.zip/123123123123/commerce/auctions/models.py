from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    def __str__(self):
        return f"{self.first_name}"

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'


class Item(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="item_list", verbose_name='Пользователи')
    title = models.CharField(max_length=64, verbose_name='Название')
    description = models.CharField(max_length=256, blank=True, verbose_name='Описание')
    img_url = models.CharField(max_length=256, blank=True, verbose_name='Изображение')
    starting_bid = models.DecimalField(decimal_places=2, max_digits=8, verbose_name='Начальная ставка')
    category = models.CharField(max_length=24, default='No Category', verbose_name='Категория')
    status = models.BooleanField(default=True, verbose_name='Статус')

    def __str__(self):
        return f"{self.title}, {self.description}"

    class Meta:
        verbose_name = 'Вещь'
        verbose_name_plural = 'Вещи'
        ordering = ['title']


class ItemCategory(models.Model):
    name = models.CharField(max_length=24, blank=False, verbose_name='Название категории')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="category_list", null=True,
                             verbose_name='Вещи')

    def __str__(self):
        return f"{self.name}"

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'
        ordering = ['name']


class Bid(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_bids", verbose_name='Пользователи')
    amount = models.DecimalField(decimal_places=2, max_digits=8, verbose_name='Изображение')
    items = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="user_bid_items", blank=True,
                              verbose_name='Вещи')

    def __str__(self):
        return f"{self.amount}"

    class Meta:
        verbose_name = 'Ставка'
        verbose_name_plural = 'Ставки'


class ItemComment(models.Model):
    text = models.TextField(max_length=512, blank=False, verbose_name='Текст комментария')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="comments_list", verbose_name='Вещи')
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Автор')
    crated_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата публикации', null=True)

    class Meta:
        verbose_name = 'Комментарий'
        verbose_name_plural = 'Комментарии'
        ordering = ['item']


class Watchlist(models.Model):
    items = models.ForeignKey(Item, on_delete=models.CASCADE, verbose_name='Вещи')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='watchlist_list', verbose_name='Пользователь')

    def __str__(self):
        return f"{self.items}, {self.user}"

    class Meta:
        verbose_name = 'Корзина'
        verbose_name_plural = 'Корзины'
        ordering = ['items']


class Category(models.Model):
    name = models.CharField(max_length=24, blank=False, verbose_name='Название категории')
    items = models.ManyToManyField(Item, blank=True, related_name="categories", verbose_name='Вещи')

    def __str__(self):
        return f"{self.name}"

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'
        ordering = ['name']


class AuctionHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="history_user")
    items = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="items_auction_history")

    def __str__(self):
        return f"{self.user.first_name}, {self.items}"

    class Meta:
        verbose_name = 'История аукциона'
        verbose_name_plural = 'Истории аукционов'


